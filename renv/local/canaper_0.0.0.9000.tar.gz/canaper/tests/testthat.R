library(testthat)
library(canaper)

test_check("canaper")
